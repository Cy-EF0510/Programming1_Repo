import java.util.Scanner;

public class WarGame {
    public static void main(String[] args) {
        int player1Wins = 0;
        int player2Wins = 0;


        Scanner input = new Scanner(System.in); 
        System.out.println("Please enter the first player's name: ");
        String player1Name = input.nextLine();
        System.out.println("Please enter the second player's name: ");  
        String player2Name = input.nextLine();
        
        Player player1 = new Player(player1Name);
        Player player2 = new Player(player2Name);


         Deck gameDeck = new Deck();
         gameDeck.shuffle();
         gameDeck.shuffle();
         gameDeck.shuffle();
 
         for(int i = 0, j = 1; i < 54 && j < 54; i+=2, j+=2){
            gameDeck.dealCard(i);
            player1.getPlayerDeck().addToDeck(gameDeck.dealCard(i));
            gameDeck.dealCard(j);
            player2.getPlayerDeck().addToDeck(gameDeck.dealCard(j));
        }        

        for(int i = 0, j = 1; i < 27 && j < 27; i++, j++){
            //Player Card
            System.out.print("Player 1: Please press \"Enter\" to deal a card: ");
            input.nextLine();
            System.out.println("Player 1 deals: " + player1.getPlayerDeck().dealCard(i));
            System.out.println("");

            
            System.out.print("Player 2: Please press \"Enter\" to deal a card: ");
            input.nextLine();
            System.out.println("Player 2 deals: " + player2.getPlayerDeck().dealCard(j));
            System.out.println("");
            
            if(player1.getPlayerDeck().dealCard(i).value > player2.getPlayerDeck().dealCard(i).value) {
                player1Wins++;
                System.out.println("Player 1 won. He currently has" + player1Wins + " wins");
            }

            if(player2.getPlayerDeck().dealCard(i).value > player1.getPlayerDeck().dealCard(i).value) {
                player2Wins++;
                System.out.println("Player 2 won. He currently has" + player2Wins + " wins");
            }

        }         

        System.out.println("This is " + player1.getName() + "'s deck: ");
        player1.getPlayerDeck().printDeck();
        System.out.println("");
        System.out.println("This is " + player2.getName() + "'s deck: ");
        player2.getPlayerDeck().printDeck();
        System.out.println("");
    }
}